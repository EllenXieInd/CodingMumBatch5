<?php
include(get_template_directory().'/core/core.php');