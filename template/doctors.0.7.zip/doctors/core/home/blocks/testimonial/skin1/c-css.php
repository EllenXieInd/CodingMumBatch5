#site-main .thbt_<?php echo $tally_home_column_block['id']; ?> .thbt_info img{
	border-color: <?php echo tally_home_style_option($tally_home['id'].'_settings_', 'bg'); ?> !important;
}
.thbt_<?php echo $tally_home_column_block['id']; ?> .thbt_info span{
	color: <?php echo tally_home_style_option($tally_home['id'].'_colors_', 'textMeta'); ?>  !important;
}
