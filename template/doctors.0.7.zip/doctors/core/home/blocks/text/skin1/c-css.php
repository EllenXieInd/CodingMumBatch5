.thbt_<?php echo $tally_home_column_block['id']; ?> .thbt_more{
	background-color:<?php echo tally_option('tally_color_accent_primary'); ?>;
}
.thbt_<?php echo $tally_home_column_block['id']; ?> .thbt_more:hover{
	background-color:<?php echo tally_option('tally_color_accent_info'); ?>;
}
.thbt_<?php echo $tally_home_column_block['id']; ?> .thbt_subtitle{
	color:<?php echo tally_option('tally_color_accent_info'); ?>;
}