.tally_homeBlock_infoBox.thBi_<?php echo $tally_home_column_block['id']; ?>{
	background-color:<?php echo tally_option($block_id.'bgColor'); ?>;
	color:<?php echo tally_option($block_id.'textColor'); ?>;
}
.tally_homeBlock_infoBox.thBi_<?php echo $tally_home_column_block['id']; ?>:hover{
	background-color:<?php echo tally_option($block_id.'bgColor_hover'); ?>;
}
#site-main .tally_homeBlock_infoBox.thBi_<?php echo $tally_home_column_block['id']; ?> .thbib_title i.fa{
	color:<?php echo tally_option($block_id.'headingColor'); ?>;
}
#site-main .tally_homeBlock_infoBox.thBi_<?php echo $tally_home_column_block['id']; ?> .thbib_title a{
	color:<?php echo tally_option($block_id.'headingColor'); ?>;
}
#site-main .tally_homeBlock_infoBox.thBi_<?php echo $tally_home_column_block['id']; ?> .thbib_title a:hover{
	color:<?php echo tally_option($block_id.'headingColor_hover'); ?>;
}
#site-main .tally_homeBlock_infoBox.thBi_<?php echo $tally_home_column_block['id']; ?> .thbib_more{
	color: <?php echo tally_option($block_id.'textColor'); ?>;
    border-color:<?php echo tally_option($block_id.'borderColor'); ?>;
}
#site-main .tally_homeBlock_infoBox.thBi_<?php echo $tally_home_column_block['id']; ?> .thbib_more:hover{
	color: <?php echo tally_option($block_id.'textColor_hover'); ?>;
    border-color:<?php echo tally_option($block_id.'borderColor_hover'); ?>;
}