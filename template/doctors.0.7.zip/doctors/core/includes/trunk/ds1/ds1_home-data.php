<?php
$tally_home_data = array();