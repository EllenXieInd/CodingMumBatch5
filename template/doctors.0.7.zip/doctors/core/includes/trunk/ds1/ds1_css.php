.tally_home_infoBox .col-holder .col.col_3{  margin-left: 0; width: 25%; margin-bottom: 0; }
@media only screen and (max-width: 768px) {	
	.tally_home_infoBox .col-holder .col.col_3{ width: 50%; }
}
@media only screen and (max-width: 600px) {	
	.tally_home_infoBox .col-holder .col.col_3{ width: 100%; }
}

.tally_home_parallax .tally_homeBlock_text.thbt_skin1 .thbt_des{ font-size: 145%; }