<?php
$tally_getver_data = array();
$tally_getver_data['part_header']	= 'skin1';
$tally_getver_data['part_footer']	= 'skin1';
$tally_getver_data['theme_url']		= 'http://tallythemes.com/product/doctors-lite-free-medical-wordpress-theme/?utm_source=theme-admin&utm_medium=click&utm_content=product-link&utm_campaign=doctors-lite';
$tally_getver_data['doc_url']		= 'http://tallythemes.com/doc-item/doctors-wordpress-theme-documentation/?utm_source=theme-admin&utm_medium=click&utm_content=doc-link&utm_campaign=doctors-lite';
$tally_getver_data['theme_name']	= 'Doctors';