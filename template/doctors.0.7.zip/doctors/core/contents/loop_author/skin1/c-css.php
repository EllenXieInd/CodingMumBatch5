.tally_loop_author .tla_info{ background-color: <?php echo tally_option('tally_color_main_bgAlt') ?>; }
#site-main .tally_loop_author .tla_posts_heading{ border-color: <?php echo tally_option('tally_color_main_heading'); ?> !important; }
.tally_loop_author .tla_post_item .tla_post_more{ background-color:<?php echo tally_option('tally_color_accent_primary'); ?>; }
.tally_loop_author .tla_post_item .tla_post_more:hover{ background-color:<?php echo tally_option('tally_color_accent_info'); ?>; }
.tally_loop_author .tla_post_item .tla_post_meta,
.tally_loop_author .tla_post_item .tla_post_meta a{ color:<?php echo tally_option('tally_color_main_textMeta'); ?>  !important; }