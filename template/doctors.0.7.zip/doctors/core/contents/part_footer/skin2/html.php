<div class="tally_footer">
	<div class="tally_footer_inner site_content_width">
    	<div class="col-holder nomargin">
        	<div class="col col_12">
            	<div class="copy_text">
            		<?php echo tally_option('tally_footer_copyright'); if(tally_option('tally_footer_credit') != ''){ echo " | "; echo tally_option('tally_footer_credit'); } ?>
                </div> 
            </div>
        </div>
    </div>
</div>