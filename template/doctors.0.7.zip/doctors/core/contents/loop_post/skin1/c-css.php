.tally_loop_post .tlp_header h4 a:hover{ color: <?php echo tally_option('tally_color_accent_primary'); ?> !important; }
.tally_loop_post .tlp_header p{ color:<?php echo tally_option('tally_color_main_textMeta'); ?>; }
.tally_loop_post .tlp_header p a{ color: <?php echo tally_option('tally_color_main_textAlt'); ?> !important; }
.tally_loop_post .tlp_more{ background-color:<?php echo tally_option('tally_color_accent_primary'); ?>; }
.tally_loop_post .tlp_more:hover{ background-color:<?php echo tally_option('tally_color_accent_info'); ?>; }