.tally_loop_single .tls_meta{ background-color:<?php echo tally_option('tally_color_main_bgAlt'); ?>; }
.tally_loop_single .tls_meta a{ color:<?php echo tally_option('tally_color_main_textAlt'); ?> !important; }
.tally_loop_single .tls_taxonomy{ background-color:<?php echo tally_option('tally_color_main_bgAlt'); ?>; }
.tally_loop_single .tls_taxonomy a:hover{ background-color:<?php echo tally_option('tally_color_accent_primary'); ?>; }
.tally_loop_single .tls_authorBio{ background-color:<?php echo tally_option('tally_color_main_bgAlt'); ?>; }