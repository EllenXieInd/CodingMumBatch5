.tally_subHeader_1{ 
	background-color:<?php echo tally_option('tally_color_subheader_bg'); ?>;
    color: <?php echo tally_option('tally_color_subheader_text'); ?>;
    background-image:url(<?php echo tally_option('tally_color_subheader_bgImage'); ?>);
	background-repeat:<?php echo tally_option('tally_color_subheader_bgImage_repeat'); ?>;
	background-position:<?php echo tally_option('tally_color_subheader_bgImage_position'); ?>;
    background-attachmen:<?php echo tally_option('tally_color_subheader_bgImage_attachment'); ?>;
    background-size:<?php echo tally_option('tally_color_subheader_bgImage_size'); ?>;
}
.tally_subHeader_1 .tsh_title{color: <?php echo tally_option('tally_color_subheader_heading'); ?>; }
.tally_subHeader_1 .tsh_subtitle{color: <?php echo tally_option('tally_color_subheader_subheading'); ?>; }
.tally_subHeader_1 .tsh_breadcrumbs a{ color: <?php echo tally_option('tally_color_subheader_text'); ?>; }