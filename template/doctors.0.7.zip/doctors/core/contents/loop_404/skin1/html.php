<div class="tally_loop_404">
	<font style="font-size:100px; line-height:100px;">404</font>
	<h2><?php _e( 'This is somewhat embarrassing, isn&rsquo;t it?', 'doctors' ); ?></h2>
	<div><?php _e( 'It looks like nothing was found at this location. Maybe try a search?', 'doctors' ); ?></div>
	<?php get_search_form(); ?>
</div>