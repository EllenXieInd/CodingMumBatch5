.tally_loop_404{ text-align: center; }
.tally_loop_404 #searchform{ margin-top: 40px; } 
.tally_loop_404 #searchform #s{ width: auto; padding: 0; height: 40px; }
.tally_loop_404 #searchform #searchsubmit{ width: 70px; padding: 0; height: 40px; }