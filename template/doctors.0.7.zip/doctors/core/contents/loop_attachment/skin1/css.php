.tally_loop_attachment .tla_image img{ box-shadow: 0 0px 7px 0 rgba(31, 31, 31, 0.13); padding: 10px; border-radius: 4px; }
.tally_loop_attachment .tla_title{ margin-top: 20px; font-size: 24px; margin-bottom: 10px; }
.tally_loop_attachment .tla_des{ padding-bottom: 20px; border-bottom: solid 1px; margin-bottom: 20px; }