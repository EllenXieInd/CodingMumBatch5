<?php
if(file_exists( tally_file_directory('includes/trunk/'.tally_config('slug').'/'.tally_config('slug').'_css.php') )){
	include( tally_file_directory('includes/trunk/'.tally_config('slug').'/'.tally_config('slug').'_css.php') );
}
?>