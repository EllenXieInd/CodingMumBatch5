<?php
/*
	WPRNING
	Don not change any code in this file. This will make your site massup
*/
$tally_getver_data_app = array();
$tally_getver_data_app['slug']	= 'ds1';