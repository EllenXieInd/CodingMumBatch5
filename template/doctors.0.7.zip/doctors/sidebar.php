<div id="sidebar" class="sidebar widget-area">
	<div id="sidebar-inner">
    	<?php tally_content_part_sidebar(); ?>
    </div>
</div>