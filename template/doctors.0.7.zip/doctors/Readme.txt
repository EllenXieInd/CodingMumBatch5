Doctors WordPress theme, Copyright (C) 2015 TallyThemes
Doctors WordPress theme is licensed under the GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see .

Doctors WordPress Theme bundles the following third-party resources:


Swipebox. - http://brutaldesign.github.io/swipebox/
License: MIT License
Copyright:  Constantin Saguin csag.co


OWL Carousel - http://owlgraphic.com/owlcarousel/
License: MIT
Copyright: owlgraphic - http://owlgraphic.com/


Font Awesome - http://fontawesome.io/
License: http://fontawesome.io/license/
Copyright: Dave Gandy - https://twitter.com/davegandy


Flexslider - http://www.woothemes.com/flexslider/
License: http://opensource.org/licenses/MIT
Copyright: WooThemes - http://www.woothemes.com


Images -
I have included some images for demo perpost. All the images from https://pixabay.com/ and License under CC0 Public Domain
License Link: https://pixabay.com/en/service/terms/#download_terms
And It allow us to include images in the theme.


== How to Use the Theme ==
We have created a well documentation of the theme please go http://tallythemes.com/doc-item/doctors-wordpress-theme-documentation/